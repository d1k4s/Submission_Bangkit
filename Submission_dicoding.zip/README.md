# Dicoding Collection Dashboard ✨

## Setup environment

```
conda create --name main-ds python=3.9
conda activate main-ds
pip install -r requirements.txt
```

## Run steamlit app

```
streamlit run dashboard.py
```

### go dirrectory or run this

```
streamlit run Dasboard/dashboard.py
```
